package com.bezkoder.spring.jwt.mongodb.models;

public enum ERole {
  ROLE_USER,
  //ROLE_MODERATOR,
  ROLE_ADMIN
}
